"""
Paquete de utilidades generales para la API de Documentos.
"""

